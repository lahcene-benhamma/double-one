/**
 * ==============================================================================
 * DOUBLE ONE — CATALOGUE DES PRODUITS (STRUCTURE DE DONNÉES)
 * Boutique de vêtements Streetwear · Bab Ezzouar, Alger
 * Téléphone / WhatsApp : 0773014399
 * Instagram : @double_one.dz
 * ==============================================================================
 * 
 * COMMENT AJOUTER DE NOUVEAUX ARTICLES :
 * ------------------------------------------------------------------------------
 * 1. Placez la photo de votre article dans le dossier "assets/articles/"
 *    (par exemple : "assets/articles/mon-hoodie.jpg").
 * 
 * 2. Ajoutez un nouvel objet dans le tableau PRODUCTS ci-dessous :
 * 
 *    {
 *      id: "prod-001",
 *      name: "Hoodie Signature Heavy Black",
 *      category: "hoodies", // Choix : "hoodies", "tshirts", "cargos", "vestes", "accessoires"
 *      description: "Coton peigné lourd 450 GSM. Coupe oversize, finitions soignées.",
 *      price: 6500, // Prix en Dinars Algériens (DA)
 *      image: "assets/articles/mon-hoodie.jpg",
 *      badge: "Nouveau", // Optionnel : "Nouveau", "Best-Seller", "Drop Limité" ou null
 *      available: true // true = en stock, false = rupture
 *    },
 * 
 * 3. Enregistrez le fichier. La page web se mettra à jour automatiquement !
 *    Si le tableau est vide [], le site affichera automatiquement le message élégant
 *    "Collection bientôt disponible" avec le bouton WhatsApp pour contacter la boutique.
 * ==============================================================================
 */

export const CATEGORIES = [
  { id: "all", name: "Tous les articles", icon: "✦" },
  { id: "hoodies", name: "Hoodies & Sweats", icon: "🧥" },
  { id: "tshirts", name: "T-Shirts Oversize", icon: "👕" },
  { id: "cargos", name: "Pantalons & Cargos", icon: "👖" },
  { id: "vestes", name: "Vestes & Outerwear", icon: "⚡" },
  { id: "accessoires", name: "Accessoires & Casquettes", icon: "🧢" }
];

/**
 * Tableau des articles en vente.
 * Laissez vide [] pour cette première version vitrine afin d'afficher
 * l'état "Collection bientôt disponible" (conforme au cahier des charges).
 */
export const PRODUCTS = [
  {
    id: "dbl-001",
    name: "Hoodie Zip Boxy Black Edition",
    category: "hoodies",
    description: "Coton peigné lourd 450 GSM, zip métal intégral, sérigraphie embossée.",
    price: 6500,
    image: "assets/articles/hoodie-zip-noir.jpg",
    badge: "Drop 01",
    available: true
  },
  {
    id: "dbl-002",
    name: "Pantalon Jogger Graphic Double One",
    category: "cargos",
    description: "Coton molleton épais, coupe loose streetwear, print signature blanc.",
    price: 5400,
    image: "assets/articles/jogger-graphic-noir.jpg",
    badge: "Bestseller",
    available: true
  },
  {
    id: "dbl-003",
    name: "Jean Baggy Skater Bleu Clair",
    category: "cargos",
    description: "Denim bleached délavé clair, coupe ultra baggy skater, finitions authentiques.",
    price: 5900,
    image: "assets/articles/jean-baggy-bleu-clair.jpg",
    badge: "Nouveau",
    available: true
  },
  {
    id: "dbl-004",
    name: "Pull Maille Côtelée Bordeaux",
    category: "vestes",
    description: "Tricot lourd col rond, coupe structurée premium, broderie iconique.",
    price: 6200,
    image: "assets/articles/pull-tricot-bordeaux.jpg",
    badge: "Premium",
    available: true
  },
  {
    id: "dbl-005",
    name: "Sweat Half-Zip Beige 'Saint'",
    category: "hoodies",
    description: "Col montant zippé métal, broderie torse glitter, intérieur fleece doux.",
    price: 6400,
    image: "assets/articles/sweat-half-zip-beige-saint.jpg",
    badge: "Édition Limitée",
    available: true
  },
  {
    id: "dbl-006",
    name: "Jean Wide Leg Noir Délavé",
    category: "cargos",
    description: "Denim lourd 13.5 oz, coupe large relaxed, délavage vintage.",
    price: 5800,
    image: "assets/articles/jean-noir-wide.jpg",
    badge: "Drop 01",
    available: true
  },
  {
    id: "dbl-007",
    name: "Hoodie Bleu 'Spirits of a Dreamer'",
    category: "hoodies",
    description: "Bleu cobalt vibrant, broderie cursive dos haute précision, coupe boxy.",
    price: 6600,
    image: "assets/articles/hoodie-bleu-spirits.jpg",
    badge: "Nouveau",
    available: true
  },
  {
    id: "dbl-008",
    name: "Jean Baggy Vintage Acid Grey",
    category: "cargos",
    description: "Denim authentique épais, coupe baggy streetwear, effet marbré.",
    price: 5800,
    image: "assets/articles/jean-gris-vintage.jpg",
    badge: "Bestseller",
    available: true
  },
  {
    id: "dbl-009",
    name: "Jean Regular Noir Surpiqûres",
    category: "cargos",
    description: "Denim brut lavé noir profond, surpiqûres blanches contrastées, coupe droite.",
    price: 5600,
    image: "assets/articles/jean-noir-surpiqures.jpg",
    badge: "Essentiel",
    available: true
  }
];

/**
 * Aperçu des futurs drops (utilisé pour illustrer ce qui arrive bientôt
 * sans tromper le client sur les stocks actuels).
 */
export const UPCOMING_DROPS = [
  {
    title: "Heavyweight Hoodies",
    subtitle: "Matière 450 GSM · Coupe Boxy",
    category: "hoodies",
    tag: "Prochain Drop"
  },
  {
    title: "Oversized Vintage Tees",
    subtitle: "Coton Lourd 280 GSM · Finition Décapée",
    category: "tshirts",
    tag: "En Arrivage"
  },
  {
    title: "Tactical Cargos & Parachutes",
    subtitle: "Poches modulaires · Toile Ripstop",
    category: "cargos",
    tag: "Bientôt"
  },
  {
    title: "Technical Bombers & Vests",
    subtitle: "Nylon mat · Zips métalliques",
    category: "vestes",
    tag: "Édition Limitée"
  }
];
