/**
 * ==============================================================================
 * DOUBLE ONE — LOGIQUE APPLICATIVE (JS)
 * Boutique Streetwear · Bab Ezzouar, Alger
 * Téléphone / WhatsApp : 0773014399
 * ==============================================================================
 */

import { PRODUCTS, CATEGORIES, UPCOMING_DROPS } from './products.js';

document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  initCategoryFilters();
  renderProductsOrEmptyState('all');
  initSmoothScroll();
});

/**
 * Gestion du menu mobile (ouvrir / fermer)
 */
function initMobileMenu() {
  const toggleBtn = document.getElementById('mobileToggleBtn');
  const navMenu = document.getElementById('navMenu');

  if (!toggleBtn || !navMenu) return;

  toggleBtn.addEventListener('click', () => {
    const isOpen = navMenu.classList.toggle('open');
    toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    toggleBtn.innerHTML = isOpen 
      ? `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`
      : `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>`;
  });

  // Fermer le menu après un clic sur un lien
  navMenu.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('open');
      toggleBtn.setAttribute('aria-expanded', 'false');
      toggleBtn.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>`;
    });
  });
}

/**
 * Initialisation des filtres de catégories
 */
function initCategoryFilters() {
  const filterContainer = document.getElementById('collectionFilterBar');
  if (!filterContainer) return;

  filterContainer.innerHTML = CATEGORIES.map((cat, idx) => `
    <button type="button" class="filter-pill ${idx === 0 ? 'active' : ''}" data-cat="${cat.id}">
      <span>${cat.icon}</span>
      <span>${cat.name}</span>
    </button>
  `).join('');

  filterContainer.querySelectorAll('.filter-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      filterContainer.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const catId = btn.getAttribute('data-cat');
      renderProductsOrEmptyState(catId);
    });
  });
}

/**
 * Rendu dynamique des articles ou affichage de l'état "Bientôt disponible"
 */
function renderProductsOrEmptyState(selectedCategory = 'all') {
  const container = document.getElementById('collectionDisplayContainer');
  if (!container) return;

  // Filtrer les articles si le catalogue en contient
  const filtered = (selectedCategory === 'all')
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === selectedCategory);

  // CAS 1 : Des articles réels sont configurés dans products.js
  if (filtered.length > 0) {
    container.innerHTML = `
      <div class="products-grid">
        ${filtered.map(product => `
          <article class="product-card">
            <div class="product-thumb-wrap">
              <img src="${product.image}" alt="${product.name}" loading="lazy">
              ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
            </div>
            <div class="product-content">
              <h3 class="product-name">${product.name}</h3>
              <p class="product-desc">${product.description || ''}</p>
              <div class="product-footer">
                <span class="product-price">${Number(product.price).toLocaleString('fr-FR')} DA</span>
                <button class="btn-product-inquire"
                   aria-label="Commander via Instagram"
                   onclick="commanderIG('${product.name.replace(/'/g, "\\'")}', '${Number(product.price).toLocaleString('fr-FR')} DA')">
                  <span>Commander</span>
                  <span>&rarr;</span>
                </button>
              </div>
            </div>
          </article>
        `).join('')}
      </div>
    `;
    return;
  }

  // CAS 2 : État vide élégant "Collection Bientôt Disponible" (v1 par défaut)
  container.innerHTML = `
    <div class="collection-empty-box">
      <div class="empty-icon-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
        </svg>
      </div>
      <span class="empty-badge">✦ PROCHAIN DROP EN PRÉPARATION</span>
      <h3 class="empty-title">Collection Bientôt Disponible</h3>
      <p class="empty-text">
        Les nouveaux articles et arrivages de la saison arrivent prochainement dans notre boutique 
        à <strong>Bab Ezzouar, Alger</strong>. Suivez-nous sur Instagram et écrivez-nous en DM 
        pour être alerté(e) en exclusivité dès la sortie du drop.
      </p>
      <div class="empty-actions">
        <a href="https://www.instagram.com/double_one.dz/" 
           target="_blank" 
           rel="noopener" 
           class="btn-primary" 
           style="background: #000; color: #fff;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.326 3.608 1.301.975.975 1.24 2.242 1.302 3.608.058 1.265.069 1.645.069 4.849s-.011 3.584-.069 4.849c-.062 1.366-.327 2.633-1.302 3.608-.975.975-2.242 1.24-3.608 1.302-1.265.058-1.645.069-4.849.069s-3.584-.011-4.849-.069c-1.366-.062-2.633-.327-3.608-1.302-.975-.975-1.24-2.242-1.302-3.608C2.175 15.584 2.163 15.204 2.163 12s.012-3.584.07-4.849c.062-1.366.326-2.633 1.301-3.608.975-.975 2.242-1.24 3.608-1.302 1.265-.058 1.645-.07 4.849-.07m0-2.163c-3.259 0-3.667.014-4.947.072-1.52.069-2.878.332-3.95 1.404C1.032 2.548.769 3.906.7 5.426.642 6.706.628 7.114.628 12s.014 5.294.072 4.574c.069 1.52.332 2.878 1.404 3.95 1.073 1.073 2.43 1.336 3.95 1.404C6.333 21.986 6.741 22 12 22s5.667-.014 4.947-.072c1.52-.069 2.878-.332 3.95-1.404 1.073-1.073 1.336-2.43 1.404-3.95.058-1.28.072-1.688.072-4.574s-.014-5.294-.072-4.574c-.069-1.52-.332-2.878-1.404-3.95-1.072-1.072-2.43-1.335-3.95-1.404C17.667.014 17.259 0 12 0z"/><path d="M12 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zm0 10.162a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
          <span>Nous suivre sur Instagram</span>
        </a>
        <a href="https://www.instagram.com/double_one.dz/?dlrf=cTQ3YzJkdnd6eWZp" 
           target="_blank" 
           rel="noopener" 
           class="btn-secondary">
          <span>Suivre @double_one.dz</span>
          <span>&nearr;</span>
        </a>
      </div>

      <!-- Aperçu des pièces prévues au catalogue -->
      <div class="upcoming-grid">
        ${UPCOMING_DROPS.map(drop => `
          <div class="upcoming-card">
            <span class="upcoming-tag">${drop.tag}</span>
            <div>
              <h4 class="upcoming-title">${drop.title}</h4>
              <p class="upcoming-sub">${drop.subtitle}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/**
 * Défilement fluide vers les sections avec surbrillance du lien actif
 */
function initSmoothScroll() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    const scrollPos = window.scrollY + 100;

    sections.forEach(sec => {
      const top = sec.offsetTop;
      const height = sec.offsetHeight;
      if (scrollPos >= top && scrollPos < top + height) {
        current = sec.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  }, { passive: true });
}
