"use client";

// Stroke Draw Type: outline type that draws itself with a pen, then fills from below like
// liquid rising in a glass. A small accent glow rides the leading end of every stroke.
// Hovering drains the fill back down; the surface is a goo-filtered mask, so the liquid
// clings to the letter tops in beads before it lets go. The glyph edges come from the text
// itself, so the type stays sharp at any DPR.

import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

export type StrokeDrawTrigger = "mount" | "in-view" | "hover" | "loop";

export interface StrokeDrawTypeProps {
  text?: string;
  strokeWidth?: number;
  color?: string;
  fillColor?: string;
  accentColor?: string;
  trigger?: StrokeDrawTrigger;
  duration?: number;
  stagger?: number;
  delay?: number;
  hold?: number;
  drainOnHover?: boolean;
  fontSize?: number;
  fontWeight?: number;
  fontFamily?: string;
  letterSpacing?: number;
  autoplay?: boolean;
  freezeAt?: number;
  seed?: number;
  ariaLabel?: string;
  className?: string;
}

const FS = 100;
const DASH_MAX = 900;
const TIP = 7;
const DROPS = 3;
const SAMPLES = 9;
const subscribeNoop = () => () => {};
const getTrue = () => true;
const getFalse = () => false;
const DEFAULT_FONT = "var(--display), 'Anton', sans-serif";

function cubicBezier(p1x: number, p1y: number, p2x: number, p2y: number) {
  const ax = 3 * p1x - 3 * p2x + 1;
  const bx = 3 * p2x - 6 * p1x;
  const cx = 3 * p1x;
  const ay = 3 * p1y - 3 * p2y + 1;
  const by = 3 * p2y - 6 * p1y;
  const cy = 3 * p1y;

  function sampleX(t: number) {
    return ((ax * t + bx) * t + cx) * t;
  }
  function sampleY(t: number) {
    return ((ay * t + by) * t + cy) * t;
  }
  function sampleDerivativeX(t: number) {
    return (3 * ax * t + 2 * bx) * t + cx;
  }

  return function solve(x: number) {
    let t = x;
    for (let i = 0; i < 8; i++) {
      const currentX = sampleX(t) - x;
      if (Math.abs(currentX) < 1e-6) return sampleY(t);
      const d = sampleDerivativeX(t);
      if (Math.abs(d) < 1e-6) break;
      t -= currentX / d;
    }
    return sampleY(t);
  };
}

const drawEase = cubicBezier(0.55, 0.06, 0.35, 1);
const fillEase = cubicBezier(0.3, 0, 0.2, 1);
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

interface Letter {
  ch: string;
  x: number;
  left: number;
  right: number;
  dash: number;
}
interface Layout {
  letters: Letter[];
  vb: [number, number, number, number];
  top: number;
  bottom: number;
}
interface Drop {
  x: number;
  r: number;
  k: number;
  off: number;
}

export function StrokeDrawType({
  text = "DOUBLE ONE",
  strokeWidth = 1.6,
  color = "#000000",
  fillColor,
  accentColor = "#ffffff",
  trigger = "in-view",
  duration = 1.5,
  stagger = 0.11,
  delay = 0.15,
  hold = 1.6,
  drainOnHover = true,
  fontSize = 160,
  fontWeight = 600,
  fontFamily = DEFAULT_FONT,
  letterSpacing = 0.02,
  autoplay = true,
  freezeAt,
  seed = 42,
  ariaLabel,
  className,
}: StrokeDrawTypeProps) {
  const ink = color;
  const fill = fillColor ?? ink;
  const accent = accentColor;
  const mounted = useSyncExternalStore(subscribeNoop, getTrue, getFalse);
  const reduced = (useReducedMotion() ?? false) && mounted;
  const frozen = freezeAt !== undefined && !reduced;
  const animated = !reduced && !frozen;

  const uid = useId().replace(/[^a-zA-Z0-9_-]/g, "");
  const ids = {
    mask: `sdt-mask-${uid}`,
    goo: `sdt-goo-${uid}`,
    glow: `sdt-glow-${uid}`,
  };

  const rootRef = useRef<HTMLDivElement>(null);
  const measureRef = useRef<SVGTextElement>(null);
  const strokeEls = useRef<(SVGTextElement | null)[]>([]);
  const tipEls = useRef<(SVGTextElement | null)[]>([]);
  const surfaceEls = useRef<(SVGPathElement | null)[]>([]);
  const dropEls = useRef<(SVGCircleElement | null)[]>([]);
  const fillGroupRef = useRef<SVGGElement>(null);
  const [layout, setLayout] = useState<Layout | null>(null);

  const sw = (strokeWidth * FS) / fontSize;

  useLayoutEffect(() => {
    const el = measureRef.current;
    if (!el) return;
    let alive = true;
    const measure = () => {
      if (!alive) return;
      let box: DOMRect;
      try {
        box = el.getBBox();
      } catch {
        return;
      }
      if (!box.width) return;
      const letters: Letter[] = [];
      let idx = 0;
      for (const ch of Array.from(text)) {
        if (ch.trim()) {
          const start = el.getStartPositionOfChar(idx);
          const ext = el.getExtentOfChar(idx);
          const w = ext.width;
          letters.push({
            ch,
            x: start.x,
            left: ext.x,
            right: ext.x + w,
            dash: Math.min(DASH_MAX, 2.4 * w + FS * 1.05),
          });
        }
        idx += ch.length;
      }
      const pad = sw * 2 + FS * 0.05;
      setLayout({
        letters,
        vb: [
          box.x - pad,
          box.y - pad,
          box.width + pad * 2,
          box.height + pad * 2,
        ],
        top: box.y,
        bottom: box.y + box.height,
      });
    };
    measure();
    document.fonts?.ready.then(measure);
    return () => {
      alive = false;
    };
  }, [text, fontFamily, fontWeight, letterSpacing, sw]);

  const n = layout?.letters.length ?? 0;
  const drawEnd = duration;
  const fillStart = duration * 0.58;
  const fillDur = duration * 0.85;
  const total = delay + Math.max(0, n - 1) * stagger + fillStart + fillDur;
  const drainDur = duration * 0.9;
  const cycle =
    total + hold + (n - 1) * stagger * 0.5 + drainDur + duration * 0.7 + 0.7;

  const drops = useMemo<Drop[]>(() => {
    if (!layout) return [];
    let s = seed;
    const rand = () => {
      s |= 0;
      s = (s + 0x6d2b79f5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    const out: Drop[] = [];
    for (const l of layout.letters) {
      const w = l.right - l.left;
      for (let d = 0; d < DROPS; d++) {
        out.push({
          x:
            l.left +
            w * (0.2 + 0.6 * ((d + 0.5) / DROPS)) +
            (rand() - 0.5) * w * 0.15,
          r: FS * (0.035 + rand() * 0.035),
          k: 55 + rand() * 110,
          off: FS * (0.02 + rand() * 0.04),
        });
      }
    }
    return out;
  }, [layout, seed]);

  const sim = useRef({
    clock: 0,
    started: false,
    hoverOn: false,
    hoverLetter: 0,
    drain: new Float64Array(0),
    hoverAt: new Float64Array(0),
    surface: new Float64Array(0),
    prevSurface: new Float64Array(0),
    dropY: new Float64Array(0),
    dropV: new Float64Array(0),
    draw: new Float64Array(0),
    level: new Float64Array(0),
  });

  useEffect(() => {
    const s = sim.current;
    s.drain = new Float64Array(n).fill(trigger === "hover" ? 1 : 0);
    s.hoverAt = new Float64Array(n);
    s.surface = new Float64Array(n);
    s.prevSurface = new Float64Array(n);
    s.dropY = new Float64Array(n * DROPS).fill(1e4);
    s.dropV = new Float64Array(n * DROPS);
    s.draw = new Float64Array(n);
    s.level = new Float64Array(n);
  }, [n, trigger]);

  const paint = useCallback(
    (
      draw: ArrayLike<number>,
      level: ArrayLike<number>,
      t: number,
      dt: number,
      settleDrops: boolean,
    ) => {
      if (!layout) return;
      const { letters, top, bottom } = layout;
      const s = sim.current;
      const lo = top - FS * 0.12;
      const hi = bottom + FS * 0.16;
      let anyPartial = false;
      for (let i = 0; i < letters.length; i++) {
        const p = draw[i];
        const stroke = strokeEls.current[i];
        const tip = tipEls.current[i];
        if (stroke) {
          if (p >= 1) {
            stroke.style.strokeDasharray = "none";
            stroke.style.strokeDashoffset = "0";
          } else {
            const L = letters[i].dash;
            stroke.style.strokeDasharray = `${L} ${L}`;
            stroke.style.strokeDashoffset = (L * (1 - p)).toFixed(2);
          }
          stroke.style.opacity = p <= 0 ? "0" : "1";
        }
        if (tip) {
          const along = p * letters[i].dash;
          tip.style.strokeDasharray = `${TIP} ${DASH_MAX * 2}`;
          tip.style.strokeDashoffset = (-(along - TIP)).toFixed(2);
          const vis = p > 0 && p < 1 ? Math.min(1, p * 12, (1 - p) * 6) : 0;
          tip.style.opacity = vis.toFixed(3);
        }

        const lv = clamp01(level[i]);
        if (lv > 0 && lv < 1) anyPartial = true;
        const y = hi + (lo - hi) * lv;
        s.prevSurface[i] = s.surface[i] || y;
        s.surface[i] = y;
        const vel = dt > 0 ? (y - s.prevSurface[i]) / dt : 0;
        const amp =
          Math.min(FS * 0.035, Math.abs(vel) * 0.012) +
          (lv > 0 && lv < 1 ? FS * 0.008 : 0);
        const l = letters[i];
        const x0 = l.left - FS * 0.08;
        const x1 = l.right + FS * 0.08;
        let d = `M${x0.toFixed(1)} ${(hi + FS).toFixed(1)}`;
        for (let k = 0; k <= SAMPLES; k++) {
          const x = x0 + ((x1 - x0) * k) / SAMPLES;
          const wy =
            y +
            amp * Math.sin(x * 0.11 + t * 7 + i * 1.7) +
            amp * 0.5 * Math.sin(x * 0.27 - t * 4.3);
          d += `L${x.toFixed(1)} ${wy.toFixed(1)}`;
        }
        d += `L${x1.toFixed(1)} ${(hi + FS).toFixed(1)}Z`;
        surfaceEls.current[i]?.setAttribute("d", d);

        for (let k = 0; k < DROPS; k++) {
          const di = i * DROPS + k;
          const drop = drops[di];
          const el = dropEls.current[di];
          if (!drop || !el) continue;
          const target = y + drop.off + drop.r;
          if (settleDrops || dt <= 0 || s.dropY[di] > 9e3) {
            s.dropY[di] = target;
            s.dropV[di] = 0;
          } else {
            const steps = 3;
            const h = dt / steps;
            for (let q = 0; q < steps; q++) {
              const a = -drop.k * (s.dropY[di] - target) - 11 * s.dropV[di];
              s.dropV[di] += a * h;
              s.dropY[di] += s.dropV[di] * h;
            }
          }
          el.setAttribute("cy", (s.dropY[di] || target).toFixed(2));
        }
      }
      const g = fillGroupRef.current;
      if (g) {
        const allFull =
          !anyPartial &&
          Array.from({ length: letters.length }, (_, i) => level[i] >= 1).every(
            Boolean,
          );
        const dropsSettled = s.dropV.every((v) => Math.abs(v) < 0.5);
        g.setAttribute(
          "mask",
          allFull && dropsSettled ? "none" : `url(#${ids.mask})`,
        );
      }
    },
    [layout, drops, ids.mask],
  );

  return (
    <div
      ref={rootRef}
      className={cn("relative flex w-full justify-center", className)}
      role={ariaLabel ? "group" : undefined}
      aria-label={ariaLabel}
    >
      <span className="sr-only">{text}</span>
      <svg
        aria-hidden="true"
        focusable="false"
        viewBox={layout?.vb ? layout.vb.map((v) => v.toFixed(2)).join(" ") : "0 -100 600 130"}
        className="block h-auto w-full overflow-visible"
      >
        <text ref={measureRef} x={0} y={0} fontSize={FS} visibility="hidden" style={{ fontFamily, fontWeight }}>
          {text}
        </text>
        {layout && (
          <g fill="none" stroke={ink} strokeWidth={sw}>
            {layout.letters.map((l, i) => (
              <text key={i} x={l.x} y={0} fontSize={FS} style={{ fontFamily, fontWeight }}>
                {l.ch}
              </text>
            ))}
          </g>
        )}
      </svg>
    </div>
  );
}

export default StrokeDrawType;
